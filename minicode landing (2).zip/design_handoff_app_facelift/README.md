# Handoff: minicode app facelift

## Overview

This handoff covers a **CSS-only visual facelift** of the minicode web app served by `minicode serve` (the `src/web/` Express+vanilla-JS frontend at `localhost:4567`). The goal is to bring the app's identity in line with the new marketing site at minicode.seanholun.com — unified teal accent, IBM Plex type system, tightened token scale, polished panel chrome.

**No JS changes. No class name changes. No structural HTML changes** — except a single 2-line patch to the `<h1>` in `src/web/index.html` to inject the SVG logo glyph next to the wordmark.

This is a **drop-in replacement** for `src/web/style.css` plus a minimal `index.html` patch.

## About the Design Files

The files in this bundle are the production-ready CSS and HTML patch. They are **not** design references — they are the actual files to commit. The visual goals were prototyped in the marketing-site project (HTML/JSX), but what's bundled here is the result already translated into the existing app's vanilla CSS conventions.

**`app-preview.html`** is a static, self-contained mockup showing roughly what the app will look like once the new CSS is applied. Use it as a visual reference for what the chat pane, header, toolbar, graph stage, and symbol detail panel should resemble after the change.

## Fidelity

**High-fidelity, drop-in.** Final colors, radii, typography, and spacing are baked into the CSS. The implementer's job is to:

1. Replace `src/web/style.css` with the file in this handoff.
2. Apply the small HTML patch to the `<h1>` element in `src/web/index.html` (logo SVG + wordmark wrapper).
3. Verify nothing JS-driven is broken — every class name has been preserved, but a careful pass through chat, graph, symbol detail, settings modal, permission modal, and config overlay is recommended.

## Files in this handoff

| File | Destination in repo | Action |
|---|---|---|
| `style.css` | `src/web/style.css` | Replace entire file |
| `index.html` | `src/web/index.html` | Replace entire file (only `<h1>` block changed vs. current) |
| `app-preview.html` | — (reference only) | Standalone visual mockup |

## What changed visually

### Token system

The previous theme was Tokyo Night-derived (`--bg: #1a1b26`, `--accent: #7aa2f7`) but inconsistent. The facelift defines a tighter token system:

```css
:root {
  /* Backgrounds — depth stack */
  --bg:          #0f1118;   /* deepest, app body */
  --bg-surface:  #161921;   /* header, footer, modals */
  --bg-hover:    #1d2130;   /* hover states */
  --bg-2:        #1a1e2a;   /* inputs, secondary cards */

  /* Text */
  --text:        #d8dff5;   /* primary */
  --text-mid:    #8d96b8;   /* secondary */
  --text-dim:    #5a6380;   /* tertiary */

  /* Accent — teal (matches landing page) */
  --accent:      #56c8d8;
  --accent-dim:  #1e4a52;
  --accent-soft: rgba(86, 200, 216, 0.12);
  --accent-line: rgba(86, 200, 216, 0.28);

  /* Semantic */
  --green:  #7dcea0;
  --yellow: #d4a84b;
  --red:    #e06c75;
  --purple: #9d8cff;

  /* Borders */
  --border:      rgba(255, 255, 255, 0.07);
  --border-mid:  rgba(255, 255, 255, 0.12);

  /* Radii — locked to 4 sizes */
  --r-sm:  4px;
  --r-md:  8px;
  --r-lg:  12px;
  --r-xl:  16px;

  /* Type */
  --font-mono: 'IBM Plex Mono', 'JetBrains Mono', 'Fira Code', 'SF Mono', Menlo, monospace;
  --font-sans: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
```

### Header

The previous header had `<h1>minicode</h1>` rendered as plain accent-colored text. The new header is:

```html
<h1>
  <span class="logo-glyph" aria-hidden="true">
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="9" y1="9" x2="22" y2="11" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity="0.55"/>
      <line x1="9" y1="9" x2="10" y2="22" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity="0.55"/>
      <line x1="22" y1="11" x2="23" y2="23" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity="0.55"/>
      <line x1="10" y1="22" x2="23" y2="23" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity="0.55"/>
      <line x1="9" y1="9" x2="23" y2="23" stroke="currentColor" stroke-width="1" stroke-linecap="round" opacity="0.35"/>
      <circle cx="9"  cy="9"  r="3"   fill="currentColor"/>
      <circle cx="22" cy="11" r="2.6" fill="currentColor" opacity="0.85"/>
      <circle cx="10" cy="22" r="2.6" fill="currentColor" opacity="0.85"/>
      <circle cx="23" cy="23" r="3"   fill="currentColor"/>
    </svg>
  </span>
  minicode
</h1>
```

The glyph is a 4-node graph: two larger nodes (top-left, bottom-right) connected diagonally, two mid nodes connecting around, with subtle ambient strokes. Renders at `currentColor`, which the CSS sets to the teal accent. This is the same mark used as the marketing site favicon and nav logo — visual continuity between site and app.

The wordmark is now `font-family: var(--font-mono)` (IBM Plex Mono), `font-size: 13px`, `font-weight: 600`, `letter-spacing: 0.04em`, `color: var(--text)`.

### Header controls

| Element | Before | After |
|---|---|---|
| Status badge (`.badge.ready`) | Flat color, no border | Subtle border ring + tighter letter-spacing |
| Context bar (`#context-bar`) | 80px × 8px | 64px × 4px, slimmer pill shape |
| Model button (`#model-btn`) | Same flat treatment as utility buttons | Distinct pill: `--bg-2` background, `--border-mid` border, max-width 240px with truncation |
| Utility buttons (`.header-btn`) | All identical | Same flat style, but graph toggle when active gets `--accent-soft` bg + accent text |

### Chat pane

| Element | Before | After |
|---|---|---|
| User message (`.message.user`) | Solid `accent-dim` blue bubble, white text | Teal-tinted (`rgba(86,200,216,0.14)`) with matching border, primary text color, asymmetric radius `--r-lg --r-lg --r-sm --r-lg` |
| Assistant message (`.message.assistant`) | Plain surface, gray border | Same surface but with 2px left accent border for visual hierarchy |
| Tool calls (`.tool-call`) | Hover = soft blue bg | Hover = `--bg-hover` + 2px left accent border that lights up on hover |
| Tool name (`.tool-name`) | Tokyo Night blue | Teal accent, weight 600 |
| Send button (`#send-btn`) | Solid accent, white text | Solid teal, dark text (`#0a0e15`) for contrast |
| Cancel button (`#cancel-btn`) | Solid red, white text | Translucent red bg + red text + matching border |
| Chat input (`#chat-input`) | Plain border | `--bg-2` background, `--border-mid`, focus → `--accent-line` |
| Footer | Same `--bg` | `--bg-surface` for visual separation from message scroll area |

### Graph toolbar

The toolbar buttons used to be visually identical, treating "Analyze" the same as "Refresh", "Fit", "Re-layout", "Clear". The new system treats Analyze as the **primary** action:

```css
#graph-analyze {
  background: var(--accent-soft);
  border-color: var(--accent-line);
  color: var(--accent);
  font-weight: 600;
}
#graph-analyze:hover {
  background: rgba(86,200,216,0.2);
  border-color: var(--accent);
}
```

The `#graph-search` input also expands from 210px → 240px on focus and uses `--bg-2` to stand out from the toolbar surface.

### Symbol detail panel (`#symbol-detail`)

Polished, not restructured. Specifically:

- `.detail-kind-badge` (e.g., `class`, `function`) — was a flat colored chip, now a teal pill with `--accent-soft` bg + `--accent-line` border + accent text.
- `.detail-section-title` — tighter uppercase treatment, 10px font, 0.08em letter-spacing.
- `.detail-link` references — accent color, hover bg fills with `--bg-hover`.
- `.detail-signature` — consistent `--bg` background, sm radius, mono font.
- `.detail-actions` button row — uses `flex: 1` so each action button stretches evenly across the panel width.

### Analysis panel (overlay)

- Border + shadow now use the accent line + a deeper drop-shadow.
- Summary cards (`.analysis-summary-card`) — flat outlined cards with subtle hover lift (`translateY(-1px)`).
- Findings cards (`.analysis-finding`) — same pattern; high-severity findings get a red accent ring.
- Severity badges use teal/yellow/red on translucent backgrounds with matching borders.

### Modals (settings, permission, file preview)

Unified treatment:

- All modals: `--bg-surface` panel, `--border-mid` border, `--r-xl` (16px) radius, dual shadow `0 32px 80px rgba(0,0,0,0.55), 0 1px 0 rgba(255,255,255,0.04) inset`.
- Backdrop: `rgba(6, 8, 14, 0.78)` + `backdrop-filter: blur(6px)`.
- Settings items: `--bg-2` cards with `--r-lg` radius.
- Pinned-path pill in settings toolbar: `--accent-soft` bg + `--accent-line` border + accent text.

### Config overlay (chat pane onboarding)

- Spotlight cards use a teal-tinted gradient instead of the previous mixed blue-green.
- Status banners (info/success/error) all share the same translucent-bg + matching-border treatment.

## Type / font loading

The new CSS expects **IBM Plex Mono** + **IBM Plex Sans** to be available. The current `index.html` loads JetBrains Mono from Google Fonts. The recommended change is to swap that link tag:

**Before:**
```html
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
```

**After:**
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

The font stack falls back gracefully (`'IBM Plex Mono', 'JetBrains Mono', ...`), so if you keep JetBrains for a transitional period the app will still render — but the marketing site uses IBM Plex and visual unity is the point of this pass.

## Things to verify post-merge

1. **`minicode serve` renders cleanly.** Walk through:
   - Header (logo glyph appears, wordmark, status badge, model selector, context bar, all 3 utility buttons)
   - Chat pane (user message, assistant message, tool calls, send/cancel buttons, input focus state)
   - Graph toolbar (Analyze button reads as primary, search expands on focus)
   - Symbol detail panel (kind badge, section titles, references list, code block)
   - Settings modal (toolbar, scope picker, banners, item cards, footer)
   - Permission modal (tool name + input pre)
   - File preview modal (code block)
   - Analysis panel overlay (summary cards, findings cards, severity badges)
   - Config overlay (when no provider configured — spotlight cards, options, footer)

2. **Cytoscape graph colors.** The graph node/edge colors are set in `graph.ts` (JS), not CSS. They will not change with this pass. Confirm they still read well against the new darker `--bg` (`#0f1118` vs old `#1a1b26`). If nodes look too blue against the new background, a follow-up tweak to the cytoscape stylesheet array in `graph.ts` is appropriate.

3. **Highlight.js theme.** The current setup uses tokyo-night-dark as the syntax highlighting theme. Confirm code blocks inside `.detail-code` and `.message.assistant pre` still look right against the new bg. If colors clash, consider switching to a slightly desaturated theme (e.g., `night-owl-monochrome` or the IBM-flavored `vscode-dark-plus`).

4. **Resize behavior.** The chat ↔ graph divider, symbol detail resize handle, and modal responsive breakpoints (760px, 900px) all need a quick visual check.

## Design tokens reference

For future development matching this design system:

| Token | Value | Usage |
|---|---|---|
| `--bg` | `#0f1118` | App body, graph stage |
| `--bg-surface` | `#161921` | Header, footer, modals |
| `--bg-hover` | `#1d2130` | Hover states |
| `--bg-2` | `#1a1e2a` | Inputs, cards inside surfaces |
| `--text` | `#d8dff5` | Primary text |
| `--text-mid` | `#8d96b8` | Secondary text |
| `--text-dim` | `#5a6380` | Tertiary, hints, metadata |
| `--accent` | `#56c8d8` | Teal — primary actions, focus, branding |
| `--accent-soft` | `rgba(86, 200, 216, 0.12)` | Active/selected backgrounds |
| `--accent-line` | `rgba(86, 200, 216, 0.28)` | Active/selected borders, focus rings |
| `--green` | `#7dcea0` | Status: ready, success |
| `--yellow` | `#d4a84b` | Status: busy, warning |
| `--red` | `#e06c75` | Status: error, destructive |
| `--border` | `rgba(255,255,255,0.07)` | Default borders |
| `--border-mid` | `rgba(255,255,255,0.12)` | Stronger borders, input outlines |
| `--r-sm` | 4px | Tags, chips, inline pills |
| `--r-md` | 8px | Buttons, inputs |
| `--r-lg` | 12px | Cards, message bubbles |
| `--r-xl` | 16px | Modals, panels |

## Branch + commit

Suggested:

```bash
git checkout -b app-facelift
# replace src/web/style.css with the file in this handoff
# replace src/web/index.html with the file in this handoff (the only change is the <h1> block)
# also update the Google Fonts link in index.html if migrating to IBM Plex
git add src/web/style.css src/web/index.html
git commit -m "App facelift: teal accent, IBM Plex, polished panels"
git push -u origin app-facelift
```

PR title: **App facelift — teal accent, logo glyph, polished panels**

PR description (suggested):
> Refreshes the `minicode serve` web UI to align visually with the new marketing site at minicode.seanholun.com.
>
> CSS-only change plus a 2-line HTML patch to add the logo glyph in the header. No JS changes, no class names changed, no structural HTML changes.
>
> Highlights:
> - New token system (`--bg`, `--text`, `--accent`, `--r-*`) with teal accent (`#56c8d8`) replacing Tokyo Night blue
> - IBM Plex Mono + IBM Plex Sans font stack matching the marketing site
> - SVG graph logo glyph in the header next to the `minicode` wordmark
> - Polished header (model selector pill, slimmer context bar)
> - Chat pane: teal-tinted user bubbles, accent-bordered assistant messages, polished tool calls
> - Graph toolbar: Analyze treated as primary action
> - Symbol detail: pill-style kind badge, tighter section headers
> - Unified modal chrome and shadow system

## Cross-references

- **Marketing site PR (separate repo):** `sean1588/minicode-site` — see `site/PR_NOTES.md` in the design project for that handoff.
- **Logo glyph SVG:** identical to `site/static/images/minicode-logo.svg` and `site/static/favicon.svg` in the marketing site repo.
